import React from 'react';
import './index.scss';

function ItemListContainer({ greeting }) {
    return <h1>{greeting}</h1>
}

export { ItemListContainer };